package com.minimouse.app;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/** Cursor shapes. Style 0 is free, 1-5 belong to the (demo) premium pack, 6 is hidden. */
final class CursorShapes {

    static final int VISIBLE = 6;
    static final int GHOST = 6;
    static final String[] NAMES = {"Arrow", "Crosshair", "Dot", "Ring", "Diamond", "Pointer"};

    private static final Path PATH = new Path();
    private static final RectF OVAL = new RectF();

    private CursorShapes() {
    }

    private static boolean centered(int style) {
        return style != 0 && style != 5;
    }

    /** Distance in px from the top-left corner of the cursor window to the click point. */
    static float hot(int style, float size, float dp) {
        return centered(style) ? size / 2f : 2f * dp;
    }

    private static void outlined(Canvas c, Paint line, float dp, int color, float outerDp,
                                 float innerDp, float cx, float cy, float r, boolean cross) {
        for (int pass = 0; pass < 2; pass++) {
            line.setStyle(Paint.Style.STROKE);
            line.setColor(pass == 0 ? 0xFF000000 : color);
            line.setStrokeWidth((pass == 0 ? outerDp : innerDp) * dp);
            if (cross) {
                c.drawLine(cx - r, cy, cx + r, cy, line);
                c.drawLine(cx, cy - r, cx, cy + r, line);
                c.drawCircle(cx, cy, r * 0.28f, line);
            } else {
                c.drawCircle(cx, cy, r, line);
            }
        }
    }

    static void draw(Canvas c, int style, float size, float dp, Paint fill, Paint line, int color) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        line.setStyle(Paint.Style.STROKE);
        line.setColor(0xFF000000);
        line.setStrokeWidth(1.5f * dp);
        float mid = size / 2f;
        float h = hot(style, size, dp);
        switch (style) {
            case 1:
                outlined(c, line, dp, color, 4f, 2f, mid, mid, size * 0.44f, true);
                break;
            case 2:
                c.drawCircle(mid, mid, size * 0.22f, fill);
                c.drawCircle(mid, mid, size * 0.22f, line);
                break;
            case 3:
                outlined(c, line, dp, color, 5.5f, 2.5f, mid, mid, size * 0.32f, false);
                c.drawCircle(mid, mid, size * 0.06f, fill);
                break;
            case 4: {
                float r = size * 0.34f;
                PATH.reset();
                PATH.moveTo(mid, mid - r);
                PATH.lineTo(mid + r, mid);
                PATH.lineTo(mid, mid + r);
                PATH.lineTo(mid - r, mid);
                PATH.close();
                c.drawPath(PATH, fill);
                c.drawPath(PATH, line);
                break;
            }
            case 5: {
                float s = size * 0.9f;
                c.save();
                c.translate(h, h);
                PATH.reset();
                PATH.moveTo(0, 0);
                PATH.lineTo(s * 0.05f, s * 0.9f);
                PATH.lineTo(s * 0.65f, s * 0.62f);
                PATH.close();
                c.drawPath(PATH, fill);
                c.drawPath(PATH, line);
                c.restore();
                break;
            }
            case GHOST: {
                float s = size * 0.9f;
                c.save();
                c.translate((size - s) / 2f, (size - s) / 2f);
                OVAL.set(0.08f * s, 0.04f * s, 0.92f * s, 0.84f * s);
                PATH.reset();
                PATH.arcTo(OVAL, 180f, 180f);
                PATH.lineTo(0.92f * s, 0.96f * s);
                PATH.lineTo(0.77f * s, 0.84f * s);
                PATH.lineTo(0.62f * s, 0.96f * s);
                PATH.lineTo(0.50f * s, 0.84f * s);
                PATH.lineTo(0.38f * s, 0.96f * s);
                PATH.lineTo(0.23f * s, 0.84f * s);
                PATH.lineTo(0.08f * s, 0.96f * s);
                PATH.close();
                c.drawPath(PATH, fill);
                c.drawPath(PATH, line);
                fill.setColor(0xFF000000);
                c.drawCircle(0.36f * s, 0.38f * s, 0.07f * s, fill);
                c.drawCircle(0.64f * s, 0.38f * s, 0.07f * s, fill);
                c.drawCircle(0.50f * s, 0.58f * s, 0.05f * s, fill);
                c.restore();
                break;
            }
            default: {
                float s = size * 0.9f;
                c.save();
                c.translate(h, h);
                PATH.reset();
                PATH.moveTo(0, 0);
                PATH.lineTo(0, s * 0.78f);
                PATH.lineTo(s * 0.20f, s * 0.60f);
                PATH.lineTo(s * 0.34f, s * 0.92f);
                PATH.lineTo(s * 0.46f, s * 0.87f);
                PATH.lineTo(s * 0.32f, s * 0.56f);
                PATH.lineTo(s * 0.58f, s * 0.56f);
                PATH.close();
                c.drawPath(PATH, fill);
                c.drawPath(PATH, line);
                c.restore();
                break;
            }
        }
    }
}
