package com.minimouse.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * On-screen mouse: a cursor overlay + a small touchpad panel.
 * Clicks, long presses, drags and scrolls are injected as touch gestures at the cursor.
 * No libraries. No permissions. Reads nothing from the screen.
 */
public class MouseService extends AccessibilityService {

    static final String PREFS = "minimouse";
    static final String KEY_SPEED = "speed";    // 0..100
    static final String KEY_CURSOR = "cursor";  // 0..40  -> 20..60 dp
    static final String KEY_RIGHT = "right";    // 0 = long press, 1 = Back
    static final String KEY_STYLE = "style";    // cursor shape 0..5
    static final String KEY_PREMIUM = "premium"; // demo purchase flag (nothing real)
    static final String KEY_CLICK = "click";    // 0 normal, 1 slow press, 2 slow press + tiny move

    private static final int OVERLAY = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
    private static final int BASE_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private Pad padView;
    private float hot;            // cursor hot-spot offset in px
    private boolean ghost;        // hidden style, never saved
    private int knocks;
    private long knockStart;
    private WindowManager wm;
    private SharedPreferences prefs;
    private SharedPreferences.OnSharedPreferenceChangeListener prefListener;
    private float dp;
    private int screenW;
    private int screenH;

    // cursor (tip position in real screen pixels)
    private float cx;
    private float cy;
    private CursorView cursor;
    private WindowManager.LayoutParams cursorLp;
    private boolean cursorPosted;

    // panel + bubble
    private FrameLayout panel;
    private WindowManager.LayoutParams panelLp;
    private TextView dragButton;
    private TextView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private boolean minimized;

    // drag state
    private boolean dragging;
    private boolean dragBusy;
    private boolean dragPending;
    private boolean dragEnding;
    private GestureDescription.StrokeDescription dragStroke;
    private float dragX;
    private float dragY;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        if (panel != null) {
            return; // already built
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        dp = getResources().getDisplayMetrics().density;
        refreshScreen();
        cx = screenW / 2f;
        cy = screenH / 2f;
        buildCursor();
        buildPanel();
        prefListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override
            public void onSharedPreferenceChanged(SharedPreferences p, String key) {
                applyPrefs();
            }
        };
        prefs.registerOnSharedPreferenceChangeListener(prefListener);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // not used
    }

    @Override
    public void onInterrupt() {
        // not used
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (panel == null) {
            return;
        }
        refreshScreen();
        cx = clampF(cx, 0, screenW - 1);
        cy = clampF(cy, 0, screenH - 1);
        panelLp.width = Math.min(panelLp.width, screenW);
        panelLp.height = Math.min(panelLp.height, screenH);
        panelLp.x = clamp(panelLp.x, 0, screenW - panelLp.width);
        panelLp.y = clamp(panelLp.y, 0, screenH - panelLp.height);
        updateCursor();
        if (!minimized) {
            safeUpdate(panel, panelLp);
        }
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        teardown();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        teardown();
        super.onDestroy();
    }

    private void teardown() {
        resetDrag();
        if (prefs != null && prefListener != null) {
            prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
        }
        removeQuietly(panel);
        removeQuietly(cursor);
        removeQuietly(bubble);
        panel = null;
        cursor = null;
        bubble = null;
    }

    // ------------------------------------------------------------------ helpers

    private void refreshScreen() {
        DisplayMetrics m = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(m);
        screenW = m.widthPixels;
        screenH = m.heightPixels;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static float clampF(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void removeQuietly(View v) {
        if (v == null || wm == null) {
            return;
        }
        try {
            wm.removeView(v);
        } catch (RuntimeException ignored) {
            // not attached
        }
    }

    private void safeUpdate(View v, WindowManager.LayoutParams lp) {
        try {
            wm.updateViewLayout(v, lp);
        } catch (RuntimeException ignored) {
            // not attached
        }
    }

    private void cutoutMode(WindowManager.LayoutParams lp) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
    }

    private float speed() {
        return 0.5f + prefs.getInt(KEY_SPEED, 40) / 100f * 3.5f;
    }

    private int cursorSizePx() {
        return (int) ((20 + prefs.getInt(KEY_CURSOR, 12)) * dp);
    }

    // ------------------------------------------------------------------ cursor

    private int currentStyle() {
        if (ghost) {
            return CursorShapes.GHOST;
        }
        if (!prefs.getBoolean(KEY_PREMIUM, false)) {
            return 0; // shapes 1-5 need the (demo) premium unlock
        }
        int st = prefs.getInt(KEY_STYLE, 0);
        return st < 0 || st >= CursorShapes.VISIBLE ? 0 : st;
    }

    private class CursorView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        boolean active;
        int style;
        float size;

        CursorView(Context c) {
            super(c);
        }

        void setShape(int newStyle, float newSize) {
            style = newStyle;
            size = newSize;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            CursorShapes.draw(c, style, size, dp, fill, line, active ? 0xFFFFB300 : 0xFFFFFFFF);
        }
    }

    private void buildCursor() {
        int size = cursorSizePx();
        int style = currentStyle();
        hot = CursorShapes.hot(style, size, dp);
        cursor = new CursorView(this);
        cursor.setShape(style, size);
        cursorLp = new WindowManager.LayoutParams(size, size, OVERLAY,
                BASE_FLAGS | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        cursorLp.gravity = Gravity.TOP | Gravity.START;
        // Android 12 can block touches that pass through a nearly opaque overlay window,
        // so keep this one slightly see-through (alpha 0.8 or less).
        cursorLp.alpha = 0.75f;
        cutoutMode(cursorLp);
        cursorLp.x = (int) (cx - hot);
        cursorLp.y = (int) (cy - hot);
        wm.addView(cursor, cursorLp);
    }

    private void updateCursor() {
        if (cursor == null) {
            return;
        }
        cursorLp.x = (int) (cx - hot);
        cursorLp.y = (int) (cy - hot);
        safeUpdate(cursor, cursorLp);
    }

    /** Update at most once per frame while the finger is sliding. */
    private void postCursor() {
        if (cursor == null || cursorPosted) {
            return;
        }
        cursorPosted = true;
        cursor.postOnAnimation(new Runnable() {
            @Override
            public void run() {
                cursorPosted = false;
                updateCursor();
            }
        });
    }

    private void applyPrefs() {
        if (cursor == null) {
            return;
        }
        int size = cursorSizePx();
        int style = currentStyle();
        hot = CursorShapes.hot(style, size, dp);
        cursorLp.width = size;
        cursorLp.height = size;
        cursor.setShape(style, size);
        updateCursor();
    }

    private void moveCursor(float dx, float dy) {
        float len = (float) Math.hypot(dx, dy);
        float accel = 1f + Math.min(1.5f, len / (10f * dp));
        float k = speed() * accel;
        cx = clampF(cx + dx * k, 0, screenW - 1);
        cy = clampF(cy + dy * k, 0, screenH - 1);
        postCursor();
        if (dragging) {
            dragPending = true;
            flushDrag();
        }
    }

    // ------------------------------------------------------------------ actions

    private GestureDescription gesture(GestureDescription.StrokeDescription s) {
        return new GestureDescription.Builder().addStroke(s).build();
    }

    private int sysW() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    private int sysH() {
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }

    private void status(String text) {
        if (padView != null) {
            padView.setStatus(text);
        }
    }

    /** Sends one tap (or long press) at x,y and shows the result on the touchpad. */
    private void tap(float x, float y, final long duration, final String label,
                     final boolean allowRetry) {
        final float px = clampF(x, 0, sysW() - 1);
        final float py = clampF(y, 0, sysH() - 1);
        int clickMode = prefs.getInt(KEY_CLICK, 0);
        long pressTime = (clickMode >= 1 && duration < 100) ? 120 : duration;
        try {
            Path p = new Path();
            p.moveTo(px, py);
            if (clickMode == 2) {
                p.lineTo(px + 1f, py);
            }
            GestureDescription g = gesture(new GestureDescription.StrokeDescription(p, 0, pressTime));
            boolean ok = dispatchGesture(g, new AccessibilityService.GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gd) {
                    status(label + " sent");
                }

                @Override
                public void onCancelled(GestureDescription gd) {
                    if (allowRetry) {
                        ui.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                tap(px, py, duration, label, false);
                            }
                        }, 150);
                    } else {
                        status(label + " was cancelled by the system");
                    }
                }
            }, null);
            if (!ok) {
                status(label + " rejected (service not ready?)");
            }
        } catch (RuntimeException e) {
            status(label + " error: " + e.getMessage());
        }
    }

    private void leftClick() {
        if (dragging) {
            endDrag(); // pressing L while dragging = drop
            return;
        }
        tap(cx, cy, 50, "Left click", true);
    }

    private void rightClick() {
        if (dragging) {
            return;
        }
        if (prefs.getInt(KEY_RIGHT, 0) == 1) {
            performGlobalAction(GLOBAL_ACTION_BACK);
            status("Back sent");
        } else {
            tap(cx, cy, 700, "Right click (long press)", true);
        }
    }

    /** up = true scrolls the content up (finger moves down). */
    private void scroll(boolean up) {
        if (dragging) {
            return;
        }
        try {
            float half = screenH * 0.18f;
            float top = clampF(cy - half, 1, screenH - 2);
            float bottom = clampF(cy + half, 1, screenH - 2);
            Path p = new Path();
            if (up) {
                p.moveTo(cx, top);
                p.lineTo(cx, bottom);
            } else {
                p.moveTo(cx, bottom);
                p.lineTo(cx, top);
            }
            dispatchGesture(gesture(new GestureDescription.StrokeDescription(p, 0, 220)),
                    null, null);
        } catch (RuntimeException e) {
            status("Scroll error: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ drag (held finger)

    private void toggleDrag() {
        if (dragging) {
            endDrag();
        } else {
            startDrag();
        }
    }

    private void startDrag() {
        try {
            dragX = cx;
            dragY = cy;
            Path p = new Path();
            p.moveTo(dragX, dragY);
            dragStroke = new GestureDescription.StrokeDescription(p, 0, 50, true);
            dragging = true;
            dragEnding = false;
            dragPending = false;
            setDragUi(true);
            sendDrag(dragStroke);
        } catch (RuntimeException e) {
            resetDrag();
        }
    }

    private void sendDrag(GestureDescription.StrokeDescription s) {
        dragBusy = true;
        boolean ok = dispatchGesture(gesture(s), new AccessibilityService.GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription g) {
                dragBusy = false;
                if (dragEnding) {
                    finishDrag();
                } else if (dragging) {
                    flushDrag();
                }
            }

            @Override
            public void onCancelled(GestureDescription g) {
                dragBusy = false;
                resetDrag();
            }
        }, null);
        if (!ok) {
            resetDrag();
        }
    }

    private void flushDrag() {
        if (!dragging || dragBusy || !dragPending) {
            return;
        }
        try {
            dragPending = false;
            Path p = new Path();
            p.moveTo(dragX, dragY);
            p.lineTo(cx, cy);
            dragStroke = dragStroke.continueStroke(p, 0, 30, true);
            dragX = cx;
            dragY = cy;
            sendDrag(dragStroke);
        } catch (RuntimeException e) {
            resetDrag();
        }
    }

    private void endDrag() {
        if (!dragging) {
            return;
        }
        dragEnding = true;
        finishDrag(); // lift the finger now, even if a move is still in flight
    }

    private void finishDrag() {
        try {
            Path p = new Path();
            p.moveTo(dragX, dragY);
            p.lineTo(cx, cy);
            GestureDescription.StrokeDescription last = dragStroke.continueStroke(p, 0, 30, false);
            dispatchGesture(gesture(last), null, null);
        } catch (RuntimeException ignored) {
            // nothing to lift
        }
        dragging = false;
        dragEnding = false;
        dragPending = false;
        setDragUi(false);
    }

    private void resetDrag() {
        dragging = false;
        dragBusy = false;
        dragEnding = false;
        dragPending = false;
        dragStroke = null;
        setDragUi(false);
    }

    private void setDragUi(boolean on) {
        if (cursor != null) {
            cursor.active = on;
            cursor.invalidate();
        }
        if (dragButton != null) {
            dragButton.setText(on ? "DROP" : "Drag");
            dragButton.setBackground(round(on ? 0xFFFFB300 : 0xFF37474F, 8));
        }
    }

    // ------------------------------------------------------------------ panel

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusDp * dp);
        return g;
    }

    private TextView button(String label, int color, int textSp, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(textSp);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(color, 8));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, MATCH, 1f);
        int m = (int) (2 * dp);
        lp.setMargins(m, m, m, m);
        t.setLayoutParams(lp);
        return t;
    }

    private void buildPanel() {
        int w = Math.min((int) (300 * dp), screenW);
        int h = Math.min((int) (290 * dp), screenH);

        panel = new FrameLayout(this);
        panel.setBackground(round(0xDD1B2430, 12));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        panel.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        col.addView(buildTopBar(), new LinearLayout.LayoutParams(MATCH, (int) (32 * dp)));

        FrameLayout padFrame = new FrameLayout(this);
        padView = new Pad(this);
        padFrame.addView(padView, new FrameLayout.LayoutParams(MATCH, MATCH));
        padFrame.addView(buildResizeHandle(), new FrameLayout.LayoutParams(
                (int) (28 * dp), (int) (28 * dp), Gravity.BOTTOM | Gravity.END));
        LinearLayout.LayoutParams padLp = new LinearLayout.LayoutParams(MATCH, 0, 1f);
        int m = (int) (4 * dp);
        padLp.setMargins(m, 0, m, m);
        col.addView(padFrame, padLp);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(button("L", 0xFF455A64, 18, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                leftClick();
            }
        }));
        row1.addView(button("R", 0xFF455A64, 18, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rightClick();
            }
        }));
        col.addView(row1, new LinearLayout.LayoutParams(MATCH, (int) (46 * dp)));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        dragButton = button("Drag", 0xFF37474F, 12, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleDrag();
            }
        });
        row2.addView(dragButton);
        row2.addView(button("Up", 0xFF37474F, 12, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scroll(true);
            }
        }));
        row2.addView(button("Dn", 0xFF37474F, 12, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scroll(false);
            }
        }));
        row2.addView(button("Back", 0xFF37474F, 12, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performGlobalAction(GLOBAL_ACTION_BACK);
            }
        }));
        row2.addView(button("Home", 0xFF37474F, 12, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performGlobalAction(GLOBAL_ACTION_HOME);
            }
        }));
        col.addView(row2, new LinearLayout.LayoutParams(MATCH, (int) (38 * dp)));

        panelLp = new WindowManager.LayoutParams(w, h, OVERLAY,
                BASE_FLAGS | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        cutoutMode(panelLp);
        panelLp.x = (screenW - w) / 2;
        panelLp.y = Math.max(0, screenH - h - (int) (24 * dp));
        wm.addView(panel, panelLp);
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("  MiniMouse  (drag here)");
        title.setTextColor(0xFFB0BEC5);
        title.setTextSize(12);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        ox = panelLp.x;
                        oy = panelLp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = clamp(ox + (int) (e.getRawX() - sx), 0,
                                screenW - panelLp.width);
                        panelLp.y = clamp(oy + (int) (e.getRawY() - sy), 0,
                                screenH - panelLp.height);
                        safeUpdate(panel, panelLp);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (Math.abs(e.getRawX() - sx) < 8 * dp && Math.abs(e.getRawY() - sy) < 8 * dp) {
                            knock();
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
        bar.addView(title, new LinearLayout.LayoutParams(0, MATCH, 1f));

        TextView min = new TextView(this);
        min.setText("\u2014");
        min.setTextColor(0xFFFFFFFF);
        min.setTextSize(16);
        min.setGravity(Gravity.CENTER);
        min.setPadding((int) (16 * dp), 0, (int) (16 * dp), 0);
        min.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                minimize();
            }
        });
        bar.addView(min, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, MATCH));
        return bar;
    }

    private View buildResizeHandle() {
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(0xCCFFB300);
        View handle = new View(this) {
            @Override
            protected void onDraw(Canvas c) {
                Path p = new Path();
                p.moveTo(getWidth(), 0);
                p.lineTo(getWidth(), getHeight());
                p.lineTo(0, getHeight());
                p.close();
                c.drawPath(p, paint);
            }
        };
        handle.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int sw, sh;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        sw = panelLp.width;
                        sh = panelLp.height;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.width = clamp(sw + (int) (e.getRawX() - sx),
                                (int) (220 * dp), screenW - panelLp.x);
                        panelLp.height = clamp(sh + (int) (e.getRawY() - sy),
                                (int) (200 * dp), screenH - panelLp.y);
                        safeUpdate(panel, panelLp);
                        return true;
                    default:
                        return true;
                }
            }
        });
        return handle;
    }

    private void knock() {
        long now = SystemClock.uptimeMillis();
        if (knocks == 0 || now - knockStart > 2500) {
            knocks = 0;
            knockStart = now;
        }
        knocks++;
        if (knocks >= 5) {
            knocks = 0;
            ghost = !ghost;
            applyPrefs();
            Toast.makeText(this, ghost ? "Boo!" : "The ghost went away.", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------ touchpad

    private class Pad extends View {
        private float lastX, lastY, downX, downY;
        private long downTime;
        private boolean moved;
        private int maxPointers;
        private final Paint hint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String statusText = "";
        private final Runnable clearStatus = new Runnable() {
            @Override
            public void run() {
                statusText = "";
                invalidate();
            }
        };

        void setStatus(String t) {
            statusText = t;
            removeCallbacks(clearStatus);
            postDelayed(clearStatus, 2500);
            invalidate();
        }

        Pad(Context c) {
            super(c);
            setBackground(round(0x33FFFFFF, 8));
            hint.setColor(0x66FFFFFF);
            hint.setTextSize(12 * dp);
            hint.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawText(statusText.length() > 0 ? statusText : "touchpad", getWidth() / 2f,
                    getHeight() / 2f, hint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = e.getX();
                    downX = lastX;
                    lastY = e.getY();
                    downY = lastY;
                    downTime = e.getEventTime();
                    moved = false;
                    maxPointers = 1;
                    return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    maxPointers = Math.max(maxPointers, e.getPointerCount());
                    lastX = e.getX(0);
                    lastY = e.getY(0);
                    return true;
                case MotionEvent.ACTION_POINTER_UP: {
                    int keep = e.getActionIndex() == 0 ? 1 : 0;
                    lastX = e.getX(keep);
                    lastY = e.getY(keep);
                    return true;
                }
                case MotionEvent.ACTION_MOVE: {
                    if (e.getPointerCount() > 1) {
                        lastX = e.getX(0);
                        lastY = e.getY(0);
                        return true; // ignore multi-finger sliding
                    }
                    float x = e.getX();
                    float y = e.getY();
                    if (!moved && Math.hypot(x - downX, y - downY) > 8 * dp) {
                        moved = true;
                    }
                    float dx = x - lastX;
                    float dy = y - lastY;
                    lastX = x;
                    lastY = y;
                    if (moved) {
                        moveCursor(dx, dy);
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP: {
                    long dur = e.getEventTime() - downTime;
                    if (!moved && dur < (maxPointers >= 2 ? 400 : 250)) {
                        if (maxPointers >= 2) {
                            rightClick();
                        } else {
                            leftClick();
                        }
                    }
                    return true;
                }
                default:
                    return true;
            }
        }
    }

    // ------------------------------------------------------------------ minimize / restore

    private void minimize() {
        if (minimized) {
            return;
        }
        endDrag();
        minimized = true;
        removeQuietly(panel);
        removeQuietly(cursor);

        int size = (int) (52 * dp);
        if (bubble == null) {
            bubble = new TextView(this);
            bubble.setText("M");
            bubble.setTextColor(0xFFFFFFFF);
            bubble.setTextSize(20);
            bubble.setGravity(Gravity.CENTER);
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.OVAL);
            gd.setColor(0xDD263238);
            gd.setStroke((int) (2 * dp), 0xFFFFB300);
            bubble.setBackground(gd);
            bubble.setOnTouchListener(new View.OnTouchListener() {
                float sx, sy;
                int ox, oy;
                boolean moved;

                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            sx = e.getRawX();
                            sy = e.getRawY();
                            ox = bubbleLp.x;
                            oy = bubbleLp.y;
                            moved = false;
                            return true;
                        case MotionEvent.ACTION_MOVE: {
                            float dx = e.getRawX() - sx;
                            float dy = e.getRawY() - sy;
                            if (Math.abs(dx) > 10 * dp || Math.abs(dy) > 10 * dp) {
                                moved = true;
                            }
                            if (moved) {
                                bubbleLp.x = clamp(ox + (int) dx, 0, screenW - bubbleLp.width);
                                bubbleLp.y = clamp(oy + (int) dy, 0, screenH - bubbleLp.height);
                                safeUpdate(bubble, bubbleLp);
                            }
                            return true;
                        }
                        case MotionEvent.ACTION_UP:
                            if (!moved) {
                                bubble.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        restore();
                                    }
                                });
                            }
                            return true;
                        default:
                            return true;
                    }
                }
            });
        }
        bubbleLp = new WindowManager.LayoutParams(size, size, OVERLAY,
                BASE_FLAGS | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        cutoutMode(bubbleLp);
        bubbleLp.x = clamp(panelLp.x + panelLp.width - size, 0, screenW - size);
        bubbleLp.y = clamp(panelLp.y, 0, screenH - size);
        wm.addView(bubble, bubbleLp);
    }

    private void restore() {
        if (!minimized || panel == null) {
            return;
        }
        removeQuietly(bubble);
        wm.addView(panel, panelLp);
        wm.addView(cursor, cursorLp);
        minimized = false;
    }
}
