package com.minimouse.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** Settings screen: enable the service, tune speed / cursor size / right-click mode. */
public class MainActivity extends Activity {

    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final SharedPreferences prefs = getSharedPreferences(MouseService.PREFS, MODE_PRIVATE);
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (20 * dp);

        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);
        scroll.addView(box);

        TextView title = new TextView(this);
        title.setText("MiniMouse");
        title.setTextSize(24);
        box.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, pad / 2, 0, pad / 2);
        box.addView(status);

        Button open = new Button(this);
        open.setText("Open accessibility settings");
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        box.addView(open);

        TextView how = new TextView(this);
        how.setText("1) Open accessibility settings, find MiniMouse (maybe under Installed apps), "
                + "turn it ON.\n"
                + "2) A cursor and a touchpad appear. Slide a finger on the pad to move the cursor.\n"
                + "3) Tap the pad or press L = left click. Two-finger tap on the pad or press R = right click.\n"
                + "4) Drag: press Drag, move the cursor, press Drag (or L) again to drop.\n"
                + "5) Up / Dn scroll at the cursor. The dash button shrinks the pad to a ball.\n"
                + "To turn it off completely, switch the service OFF in accessibility settings.");
        how.setPadding(0, pad / 2, 0, pad / 2);
        box.addView(how);

        addSeek(box, "Cursor speed", MouseService.KEY_SPEED, 100, 40, prefs);
        addSeek(box, "Cursor size", MouseService.KEY_CURSOR, 40, 12, prefs);

        TextView rcTitle = new TextView(this);
        rcTitle.setText("Right click does:");
        rcTitle.setPadding(0, pad / 2, 0, 0);
        box.addView(rcTitle);

        RadioGroup group = new RadioGroup(this);
        RadioButton longPress = new RadioButton(this);
        longPress.setId(100);
        longPress.setText("Long press at the cursor (this is right click in the Godot editor "
                + "when 'Enable Long Press as Right Click' is on)");
        RadioButton back = new RadioButton(this);
        back.setId(101);
        back.setText("Back button");
        group.addView(longPress);
        group.addView(back);
        group.check(prefs.getInt(MouseService.KEY_RIGHT, 0) == 1 ? 101 : 100);
        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int checkedId) {
                prefs.edit().putInt(MouseService.KEY_RIGHT, checkedId == 101 ? 1 : 0).apply();
            }
        });
        box.addView(group);

        setContentView(scroll);
    }

    private void addSeek(LinearLayout box, String label, final String key, int max, int def,
                         final SharedPreferences prefs) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setPadding(0, (int) (12 * getResources().getDisplayMetrics().density), 0, 0);
        box.addView(t);
        SeekBar bar = new SeekBar(this);
        bar.setMax(max);
        bar.setProgress(prefs.getInt(key, def));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                if (fromUser) {
                    prefs.edit().putInt(key, progress).apply();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        box.addView(bar);
    }

    @Override
    protected void onResume() {
        super.onResume();
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean on = enabled != null && enabled.contains(getPackageName() + "/");
        status.setText(on ? "Service: ON" : "Service: OFF (enable it in accessibility settings)");
    }
}
