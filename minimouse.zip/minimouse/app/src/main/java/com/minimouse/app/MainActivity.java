package com.minimouse.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/** Settings: service switch, speed, cursor size and style, click options, test target. */
public class MainActivity extends Activity {

    private static final String DEMO_CARD = "4242424242424242";

    private TextView status;
    private SharedPreferences prefs;
    private float dp;

    /** One small box that previews a cursor shape. */
    private static final class StyleView extends View {
        private final int style;
        private final boolean locked;
        private final boolean selected;
        private final float density;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

        StyleView(Context c, int style, boolean locked, boolean selected) {
            super(c);
            this.style = style;
            this.locked = locked;
            this.selected = selected;
            density = c.getResources().getDisplayMetrics().density;
            text.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(selected ? 0xFF37474F : 0xFF232B31);
            c.drawRoundRect(0, 0, w, h, 8 * density, 8 * density, fill);
            if (selected) {
                line.setStyle(Paint.Style.STROKE);
                line.setColor(0xFFFFB300);
                line.setStrokeWidth(2 * density);
                c.drawRoundRect(1 * density, 1 * density, w - density, h - density,
                        8 * density, 8 * density, line);
            }
            float size = 40 * density;
            c.save();
            c.translate((w - size) / 2f, 8 * density);
            CursorShapes.draw(c, style, size, density, fill, line, 0xFFFFFFFF);
            c.restore();
            text.setColor(0xFFCFD8DC);
            text.setTextSize(11 * density);
            c.drawText(CursorShapes.NAMES[style], w / 2f, h - 7 * density, text);
            if (locked) {
                text.setColor(0xFFFFB300);
                text.setTextSize(10 * density);
                c.drawText("PRO", w - 16 * density, 14 * density, text);
            }
        }
    }

    private TextView label(String s, int topPadDp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setPadding(0, (int) (topPadDp * dp), 0, 0);
        return t;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(MouseService.PREFS, MODE_PRIVATE);
        dp = getResources().getDisplayMetrics().density;
        int pad = (int) (20 * dp);

        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);
        scroll.addView(box);

        TextView title = new TextView(this);
        title.setText("MiniMouse");
        title.setTextSize(24);
        title.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(MainActivity.this,
                        "Where the pad is dragged, five quick knocks wake the one who is not there.",
                        Toast.LENGTH_LONG).show();
                return true;
            }
        });
        box.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, pad / 2, 0, pad / 2);
        box.addView(status);

        box.addView(button("Open accessibility settings", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }));

        TextView how = label("1) Open accessibility settings, find MiniMouse (maybe under Installed "
                + "apps), turn it ON.\n"
                + "2) A cursor and a touchpad appear. Slide a finger on the pad to move the cursor.\n"
                + "3) Tap the pad or press L = left click. Two-finger tap or R = right click.\n"
                + "4) Drag: press Drag, move the cursor, press Drag (or L) again to drop.\n"
                + "5) Up / Dn scroll at the cursor. The dash button shrinks the pad to a ball.\n"
                + "The line of text on the pad tells you what happened to each click.", 10);
        box.addView(how);

        // ---- speed and size
        box.addView(label("Cursor speed", 14));
        box.addView(seek(MouseService.KEY_SPEED, 100, 40));
        box.addView(label("Cursor size", 10));
        box.addView(seek(MouseService.KEY_CURSOR, 40, 12));

        // ---- cursor style (demo premium)
        boolean premium = prefs.getBoolean(MouseService.KEY_PREMIUM, false);
        int current = prefs.getInt(MouseService.KEY_STYLE, 0);
        box.addView(label("Cursor style" + (premium ? " (Premium unlocked - demo)" : " (more shapes: Premium)"), 18));
        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int k = 0; k < 3; k++) {
                final int style = r * 3 + k;
                boolean locked = style != 0 && !premium;
                StyleView sv = new StyleView(this, style, locked, premium ? style == current : style == 0);
                sv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (style == 0 || prefs.getBoolean(MouseService.KEY_PREMIUM, false)) {
                            prefs.edit().putInt(MouseService.KEY_STYLE, style).apply();
                            recreate();
                        } else {
                            showCheckout(style);
                        }
                    }
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) (74 * dp), 1f);
                int m = (int) (3 * dp);
                lp.setMargins(m, m, m, m);
                row.addView(sv, lp);
            }
            box.addView(row);
        }
        if (premium) {
            box.addView(button("Lock Premium again (demo)", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    prefs.edit().putBoolean(MouseService.KEY_PREMIUM, false)
                            .putInt(MouseService.KEY_STYLE, 0).apply();
                    recreate();
                }
            }));
        } else {
            box.addView(button("Unlock Premium (demo) - $4.99", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showCheckout(1);
                }
            }));
        }

        // ---- right click mode
        box.addView(label("Right click does:", 18));
        RadioGroup rc = new RadioGroup(this);
        RadioButton longPress = new RadioButton(this);
        longPress.setId(100);
        longPress.setText("Long press at the cursor (right click in the Godot editor when "
                + "'Enable Long Press as Right Click' is on)");
        RadioButton back = new RadioButton(this);
        back.setId(101);
        back.setText("Back button");
        rc.addView(longPress);
        rc.addView(back);
        rc.check(prefs.getInt(MouseService.KEY_RIGHT, 0) == 1 ? 101 : 100);
        rc.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int id) {
                prefs.edit().putInt(MouseService.KEY_RIGHT, id == 101 ? 1 : 0).apply();
            }
        });
        box.addView(rc);

        // ---- click style (if clicks do nothing, try the other ones)
        box.addView(label("Click style (if clicks do nothing, try the next one):", 14));
        RadioGroup cs = new RadioGroup(this);
        String[] names = {"Normal (50 ms press)", "Slow press (120 ms)", "Slow press + tiny move"};
        for (int i = 0; i < 3; i++) {
            RadioButton b = new RadioButton(this);
            b.setId(300 + i);
            b.setText(names[i]);
            cs.addView(b);
        }
        cs.check(300 + prefs.getInt(MouseService.KEY_CLICK, 0));
        cs.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int id) {
                prefs.edit().putInt(MouseService.KEY_CLICK, id - 300).apply();
            }
        });
        box.addView(cs);

        // ---- test target
        box.addView(label("Click test: move the cursor onto this button and use L / R.", 18));
        final int[] counts = new int[2];
        final Button target = new Button(this);
        target.setText("Test target - clicks: 0, long presses: 0");
        target.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counts[0]++;
                target.setText("Test target - clicks: " + counts[0] + ", long presses: " + counts[1]);
            }
        });
        target.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                counts[1]++;
                target.setText("Test target - clicks: " + counts[0] + ", long presses: " + counts[1]);
                return true;
            }
        });
        box.addView(target);

        setContentView(scroll);
    }

    private SeekBar seek(final String key, int max, int def) {
        SeekBar bar = new SeekBar(this);
        bar.setMax(max);
        bar.setProgress(prefs.getInt(key, def));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                if (fromUser) {
                    prefs.edit().putInt(key, progress).apply();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        return bar;
    }

    /** A fake checkout. It never stores or sends anything, and only accepts a demo card. */
    private void showCheckout(final int wantedStyle) {
        int pad = (int) (18 * dp);
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(pad, pad / 2, pad, 0);

        final TextView warn = new TextView(this);
        warn.setText("DEMO ONLY. No real payment happens and nothing you type is saved or sent "
                + "(this app has no internet permission). Do NOT enter a real card: only the "
                + "demo card below is accepted.");
        form.addView(warn);

        final EditText card = new EditText(this);
        card.setHint("Card number");
        card.setText("4242 4242 4242 4242");
        card.setSingleLine(true);
        form.addView(card);

        final EditText exp = new EditText(this);
        exp.setHint("MM/YY");
        exp.setText("12/30");
        exp.setSingleLine(true);
        form.addView(exp);

        final EditText cvc = new EditText(this);
        cvc.setHint("CVC");
        cvc.setText("123");
        cvc.setSingleLine(true);
        form.addView(cvc);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("MiniMouse Premium (demo)")
                .setView(form)
                .setPositiveButton("Pay $4.99 (demo)", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.show();
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String digits = card.getText().toString().replaceAll("\\s", "");
                if (!DEMO_CARD.equals(digits)) {
                    card.setError("Only the demo card 4242 4242 4242 4242 works here");
                    return;
                }
                if (exp.getText().toString().trim().length() == 0
                        || cvc.getText().toString().trim().length() == 0) {
                    warn.setText("Fill in the demo expiry and CVC (any value).");
                    return;
                }
                warn.setText("Processing the demo payment...");
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setEnabled(false);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing()) {
                            return;
                        }
                        prefs.edit().putBoolean(MouseService.KEY_PREMIUM, true)
                                .putInt(MouseService.KEY_STYLE, wantedStyle).apply();
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this,
                                "Payment successful (demo). Premium unlocked!", Toast.LENGTH_LONG).show();
                        recreate();
                    }
                }, 1600);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean on = enabled != null && enabled.contains(getPackageName() + "/");
        status.setText(on ? "Service: ON" : "Service: OFF (enable it in accessibility settings)");
    }
}
