package com.minikeys.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

/**
 * The whole keyboard is ONE View that paints itself with a Canvas.
 * No child views per key, no images, no animations, no dictionary: very low memory.
 */
public class KeyboardView extends View {

    private static final int T_CHAR = 0;
    private static final int T_SHIFT = 1;
    private static final int T_BKSP = 2;
    private static final int T_SPACE = 3;
    private static final int T_ENTER = 4;
    private static final int T_LAYER = 5;
    private static final int T_LANG = 6;
    private static final int T_TRANS = 7;
    private static final int T_SPACER = 8;
    private static final int T_SYM2 = 9;

    private static final int M_NONE = 0;
    private static final int M_DRAG = 1;
    private static final int M_RESIZE = 2;
    private static final int M_KBD = 3;
    private static final int M_HIDE = 4;
    private static final int M_PREVIEW = 5;

    private static final String ARABIC_NAME = "\u0639\u0631\u0628\u064a";
    private static final String ARABIC_LETTER = "\u0639";
    private static final String ARABIC_COMMA = "\u060c";
    private static final String[] AR1 = {"\u0636", "\u0635", "\u062b", "\u0642", "\u0641", "\u063a", "\u0639", "\u0647", "\u062e", "\u062d", "\u062c", "\u062f"};
    private static final String[] AR2 = {"\u0634", "\u0633", "\u064a", "\u0628", "\u0644", "\u0627", "\u062a", "\u0646", "\u0645", "\u0643", "\u0637"};
    private static final String[] AR3 = {"\u0626", "\u0621", "\u0624", "\u0631", "\u0644\u0627", "\u0649", "\u0629", "\u0648", "\u0632", "\u0638"};
    private static final String[] AR1S = {"\u064e", "\u064b", "\u064f", "\u064c", "\u0644\u0625", "\u0625", "\u2018", "\u00f7", "\u00d7", "\u061b", "<", ">"};
    private static final String[] AR2S = {"\u0650", "\u064d", "]", "[", "\u0644\u0623", "\u0623", "\u0640", "\u060c", "/", ":", "\""};
    private static final String[] AR3S = {"~", "\u0652", "}", "{", "\u0644\u0622", "\u0622", "\u2019", ",", ".", "\u061f"};
    private static final String[] SYM2_R1 = {"\u0660", "\u0661", "\u0662", "\u0663", "\u0664", "\u0665", "\u0666", "\u0667", "\u0668", "\u0669"};
    private static final String[] SYM2_R3 = {"<", ">", "_", "\u060c", "\u061b", "\u061f", "\u20ac"};

    private static final class Key {
        final String label;
        final String out;
        final int type;
        final float weight;
        final RectF r = new RectF();
        final RectF cell = new RectF();

        Key(String label, String out, int type, float weight) {
            this.label = label;
            this.out = out;
            this.type = type;
            this.weight = weight;
        }
    }

    private final KeysService svc;
    private final float dp;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<Key[]> rows = new ArrayList<Key[]>();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF btnKbd = new RectF();
    private final RectF btnHide = new RectF();
    private final RectF grip = new RectF();
    private final RectF previewRect = new RectF();
    private final Key[] pressed = new Key[10];

    private boolean arabic;
    private int layer;          // 0 letters, 1 symbols, 2 more symbols
    private int shift;          // 0 off, 1 once, 2 locked
    private long lastShiftTap;
    private String enterLabel = "Enter";
    private boolean canTranslate = true;
    private String preview = "";
    private boolean previewReady;
    private final float topH;
    private final float previewH;

    private int mode = M_NONE;
    private int primaryId = -1;
    private float sx;
    private float sy;
    private int ox;
    private int oy;
    private int ow;
    private int oh;

    private final Runnable repeat = new Runnable() {
        @Override
        public void run() {
            svc.backspace();
            handler.postDelayed(this, 55);
        }
    };

    public KeyboardView(Context ctx, KeysService service) {
        super(ctx);
        svc = service;
        dp = ctx.getResources().getDisplayMetrics().density;
        topH = 28 * dp;
        previewH = 26 * dp;
        rebuild();
    }

    // ------------------------------------------------------------------ state from the service

    void configure(boolean useArabic, int startLayer, String enter, boolean translateOk) {
        arabic = useArabic;
        layer = startLayer;
        shift = 0;
        enterLabel = enter;
        canTranslate = translateOk;
        rebuild();
        invalidate();
    }

    void setPreview(String s, boolean ready) {
        preview = s;
        previewReady = ready;
        invalidate();
    }

    void release() {
        handler.removeCallbacks(repeat);
    }

    // ------------------------------------------------------------------ layouts

    private static Key[] join(ArrayList<Key> l) {
        return l.toArray(new Key[0]);
    }

    private static boolean isMark(String s) {
        return s.length() == 1 && Character.getType(s.charAt(0)) == Character.NON_SPACING_MARK;
    }

    private Key[] fromArray(String[] a, boolean upper) {
        Key[] r = new Key[a.length];
        for (int i = 0; i < a.length; i++) {
            String s = upper ? a[i].toUpperCase() : a[i];
            r[i] = new Key(isMark(s) ? "\u0640" + s : s, s, T_CHAR, 1f);
        }
        return r;
    }

    private Key[] fromString(String s, boolean upper) {
        String[] a = new String[s.length()];
        for (int i = 0; i < s.length(); i++) {
            a[i] = String.valueOf(s.charAt(i));
        }
        return fromArray(a, upper);
    }

    private Key[] spaced(Key[] keys) {
        ArrayList<Key> l = new ArrayList<Key>();
        l.add(new Key("", null, T_SPACER, 0.5f));
        for (Key k : keys) {
            l.add(k);
        }
        l.add(new Key("", null, T_SPACER, 0.5f));
        return join(l);
    }

    private String shiftLabel() {
        return shift == 2 ? "CAPS" : "Shift";
    }

    private Key[] lastLetterRow(Key[] letters, float sideWeight) {
        ArrayList<Key> l = new ArrayList<Key>();
        l.add(new Key(shiftLabel(), null, T_SHIFT, sideWeight));
        for (Key k : letters) {
            l.add(k);
        }
        l.add(new Key("Del", null, T_BKSP, sideWeight));
        return join(l);
    }

    private Key[] symbolLastRow(String toggleLabel, int toggleType, Key[] mid) {
        ArrayList<Key> l = new ArrayList<Key>();
        l.add(new Key(toggleLabel, null, toggleType, 1.5f));
        for (Key k : mid) {
            l.add(k);
        }
        l.add(new Key("Del", null, T_BKSP, 1.5f));
        return join(l);
    }

    private Key[] bottomRow() {
        Key[] r = new Key[7];
        r[0] = new Key(layer == 0 ? "123" : "ABC", null, T_LAYER, 1.4f);
        r[1] = new Key(arabic ? "EN" : ARABIC_LETTER, null, T_LANG, 1.1f);
        r[2] = new Key("Tr", null, T_TRANS, 1.1f);
        r[3] = new Key(arabic ? ARABIC_COMMA : ",", arabic ? ARABIC_COMMA : ",", T_CHAR, 0.9f);
        r[4] = new Key(arabic ? ARABIC_NAME : "English", " ", T_SPACE, 3.8f);
        r[5] = new Key(".", ".", T_CHAR, 0.9f);
        r[6] = new Key(enterLabel, null, T_ENTER, 1.7f);
        return r;
    }

    private void rebuild() {
        rows.clear();
        if (layer == 0) {
            boolean s = shift != 0;
            if (arabic) {
                rows.add(fromArray(s ? AR1S : AR1, false));
                rows.add(spaced(fromArray(s ? AR2S : AR2, false)));
                rows.add(lastLetterRow(fromArray(s ? AR3S : AR3, false), 1f));
            } else {
                rows.add(fromString("qwertyuiop", s));
                rows.add(spaced(fromString("asdfghjkl", s)));
                rows.add(lastLetterRow(fromString("zxcvbnm", s), 1.5f));
            }
        } else if (layer == 1) {
            rows.add(fromString("1234567890", false));
            rows.add(fromString("@#$%&-+()/", false));
            rows.add(symbolLastRow("#+=", T_SYM2, fromString("*\"':;!?", false)));
        } else {
            rows.add(fromArray(SYM2_R1, false));
            rows.add(fromString("~`|^={}[]\\", false));
            rows.add(symbolLastRow("123", T_SYM2, fromArray(SYM2_R3, false)));
        }
        rows.add(bottomRow());
        layoutKeys();
    }

    private void layoutKeys() {
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) {
            return;
        }
        float gap = 3 * dp;
        float top = topH + previewH;
        float rowH = (h - top) / rows.size();
        for (int i = 0; i < rows.size(); i++) {
            Key[] row = rows.get(i);
            float total = 0;
            for (Key k : row) {
                total += k.weight;
            }
            float unit = w / total;
            float x = 0;
            float y = top + i * rowH;
            for (Key k : row) {
                float kw = k.weight * unit;
                k.cell.set(x, y, x + kw, y + rowH);
                k.r.set(x + gap / 2, y + gap / 2, x + kw - gap / 2, y + rowH - gap / 2);
                x += kw;
            }
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float bw = 46 * dp;
        grip.set(w - 36 * dp, 0, w, topH);
        btnHide.set(grip.left - bw, 0, grip.left, topH);
        btnKbd.set(btnHide.left - bw, 0, btnHide.left, topH);
        previewRect.set(0, topH, w, topH + previewH);
        layoutKeys();
    }

    // ------------------------------------------------------------------ drawing

    private float baseline(float cy, Paint p) {
        return cy - (p.ascent() + p.descent()) / 2f;
    }

    private boolean isDown(Key k) {
        for (Key p : pressed) {
            if (p == k) {
                return true;
            }
        }
        return false;
    }

    private void drawSmallButton(Canvas c, RectF r, String label) {
        fill.setColor(0xFF2E353C);
        c.drawRoundRect(r.left + 3 * dp, r.top + 3 * dp, r.right - 3 * dp, r.bottom - 3 * dp,
                5 * dp, 5 * dp, fill);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(11 * dp);
        text.setColor(0xFFECEFF1);
        c.drawText(label, r.centerX(), baseline(r.centerY(), text), text);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        c.drawColor(0xF0171B1F);

        // top strip: drag area, switch keyboard, hide, resize grip
        fill.setColor(0xFF222A31);
        c.drawRect(0, 0, w, topH, fill);
        text.setTextAlign(Paint.Align.LEFT);
        text.setTextSize(11 * dp);
        text.setColor(0xFF78909C);
        c.drawText("MiniKeys - drag here", 8 * dp, baseline(topH / 2, text), text);
        drawSmallButton(c, btnKbd, "Kbd");
        drawSmallButton(c, btnHide, "Hide");
        fill.setColor(0xCCFFB300);
        path.reset();
        path.moveTo(w - 4 * dp, 4 * dp);
        path.lineTo(w - 4 * dp, topH - 4 * dp);
        path.lineTo(w - 26 * dp, 4 * dp);
        path.close();
        c.drawPath(path, fill);

        // preview strip (translation result)
        fill.setColor(0xFF1D2328);
        c.drawRect(0, topH, w, topH + previewH, fill);
        text.setTextAlign(Paint.Align.LEFT);
        text.setTextSize(12 * dp);
        text.setColor(previewReady ? 0xFFFFD54F : 0xFF90A4AE);
        String shown = preview.length() == 0 ? "Tr: translate the selection or the current line" : preview;
        CharSequence cut = TextUtils.ellipsize(shown, new android.text.TextPaint(text),
                w - 16 * dp, TextUtils.TruncateAt.END);
        c.drawText(cut, 0, cut.length(), 8 * dp, baseline(topH + previewH / 2, text), text);

        // keys
        text.setTextAlign(Paint.Align.CENTER);
        for (Key[] row : rows) {
            for (Key k : row) {
                if (k.type == T_SPACER) {
                    continue;
                }
                boolean down = isDown(k);
                boolean special = k.type != T_CHAR && k.type != T_SPACE;
                int color = down ? 0xFF56626D : (special ? 0xFF3B444C : 0xFF2E353C);
                if (k.type == T_SHIFT && shift != 0) {
                    color = shift == 2 ? 0xFFFFB300 : 0xFF7A5C00;
                }
                fill.setColor(color);
                c.drawRoundRect(k.r, 6 * dp, 6 * dp, fill);
                float rowH = k.r.height();
                int len = k.label.length();
                text.setTextSize(len <= 1 ? rowH * 0.42f : (len == 2 ? rowH * 0.34f : rowH * 0.26f));
                boolean dim = k.type == T_TRANS && !canTranslate;
                text.setColor(dim ? 0xFF607D8B : (k.type == T_SHIFT && shift == 2 ? 0xFF000000 : 0xFFECEFF1));
                c.drawText(k.label, k.r.centerX(), baseline(k.r.centerY(), text), text);
            }
        }
    }

    // ------------------------------------------------------------------ touch

    private Key hit(float x, float y) {
        for (Key[] row : rows) {
            for (Key k : row) {
                if (k.type != T_SPACER && k.cell.contains(x, y)) {
                    return k;
                }
            }
        }
        return null;
    }

    private void startWindowGesture(MotionEvent e, int m) {
        mode = m;
        sx = e.getRawX();
        sy = e.getRawY();
        ox = svc.winX();
        oy = svc.winY();
        ow = svc.winW();
        oh = svc.winH();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int idx = e.getActionIndex();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                primaryId = e.getPointerId(0);
                mode = M_NONE;
                pointerDown(e, 0);
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                pointerDown(e, idx);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (mode == M_DRAG) {
                    svc.moveTo(ox + (int) (e.getRawX() - sx), oy + (int) (e.getRawY() - sy));
                } else if (mode == M_RESIZE) {
                    int dx = (int) (e.getRawX() - sx);
                    int dy = (int) (e.getRawY() - sy);
                    svc.resizeTopRight(ox, oy + oh, ow + dx, oh - dy);
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                pointerUp(e, idx);
                return true;
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(repeat);
                for (int i = 0; i < pressed.length; i++) {
                    pressed[i] = null;
                }
                mode = M_NONE;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private void pointerDown(MotionEvent e, int idx) {
        float x = e.getX(idx);
        float y = e.getY(idx);
        int id = e.getPointerId(idx);
        if (id >= pressed.length) {
            return;
        }
        if (id == primaryId && y < topH) {
            if (grip.contains(x, y)) {
                startWindowGesture(e, M_RESIZE);
            } else if (btnHide.contains(x, y)) {
                mode = M_HIDE;
            } else if (btnKbd.contains(x, y)) {
                mode = M_KBD;
            } else {
                startWindowGesture(e, M_DRAG);
            }
            return;
        }
        if (id == primaryId && previewRect.contains(x, y)) {
            mode = M_PREVIEW;
            return;
        }
        Key k = hit(x, y);
        if (k != null) {
            pressed[id] = k;
            keyDown(k);
            invalidate();
        }
    }

    private void pointerUp(MotionEvent e, int idx) {
        int id = e.getPointerId(idx);
        float x = e.getX(idx);
        float y = e.getY(idx);
        if (id == primaryId) {
            if (mode == M_DRAG || mode == M_RESIZE) {
                svc.saveBounds();
            } else if (mode == M_HIDE && btnHide.contains(x, y)) {
                svc.hideByUser();
            } else if (mode == M_KBD && btnKbd.contains(x, y)) {
                svc.switchKeyboard();
            } else if (mode == M_PREVIEW && previewRect.contains(x, y)) {
                svc.applyPreview();
            }
            mode = M_NONE;
        }
        if (id < pressed.length && pressed[id] != null) {
            if (pressed[id].type == T_BKSP) {
                handler.removeCallbacks(repeat);
            }
            pressed[id] = null;
            invalidate();
        }
    }

    private void keyDown(Key k) {
        switch (k.type) {
            case T_CHAR:
                svc.type(k.out);
                if (shift == 1) {
                    shift = 0;
                    rebuild();
                }
                break;
            case T_SPACE:
                svc.type(" ");
                break;
            case T_BKSP:
                svc.backspace();
                handler.removeCallbacks(repeat);
                handler.postDelayed(repeat, 420);
                break;
            case T_ENTER:
                svc.enter();
                break;
            case T_SHIFT: {
                long now = SystemClock.uptimeMillis();
                if (shift == 0) {
                    shift = 1;
                } else if (shift == 1) {
                    shift = (now - lastShiftTap < 400) ? 2 : 0;
                } else {
                    shift = 0;
                }
                lastShiftTap = now;
                rebuild();
                break;
            }
            case T_LAYER:
                layer = layer == 0 ? 1 : 0;
                shift = 0;
                rebuild();
                break;
            case T_SYM2:
                layer = layer == 1 ? 2 : 1;
                rebuild();
                break;
            case T_LANG:
                arabic = !arabic;
                layer = 0;
                shift = 0;
                svc.saveLanguage(arabic);
                rebuild();
                break;
            case T_TRANS:
                svc.translate();
                break;
            default:
                break;
        }
    }
}
